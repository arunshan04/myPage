#!/usr/bin/python
import sys;
import json;

for line in sys.stdin:
    line = line.split('\t')
    if line[0].strip():
        line = json.loads(line[0])
        print ('%s\t%s\t%s' % (line['fqdn_no_www'].encode('utf-8'),json.dumps(line),None))
    else:
        line = json.loads(line[1])
        print ('%s\t%s\t%s' % (line['fqdn_no_www'].encode('utf-8'),None,json.dumps(line)))

