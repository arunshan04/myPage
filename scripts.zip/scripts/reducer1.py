#!/usr/bin/python2
import sys
import json
prev_fqdn_no_www=None
prev_lname=None
lineorder=[]
dwdate=[]
fullJson={}
jsonLst=[]
fqdn_no_www=None

def processUpdates(jsonLst,fullJson):
    modified=False
    if fullJson:
        for i in jsonLst:
            if not fullJson['records'].get(str(i['process_time_epoch'])):
                fullJson['records'][i['process_time_epoch']]={k: i[k] for k in set(list(i.keys())) - set(['fqdn_no_www'])}
                modified=True
            else:
                pass
    else:
        fullJson={'records':{}}
        for i in jsonLst:
            fullJson["fqdn_no_www"]=i['fqdn_no_www']
            fullJson["records"][i['process_time_epoch']]={k: i[k] for k in set(list(i.keys())) - set(['fqdn_no_www'])}
            modified=True
    if modified:
        return json.dumps(fullJson)

for line in sys.stdin:
   line = line.split('\t')
   fqdn_no_www=line[0]
   if ( fqdn_no_www != prev_fqdn_no_www ) and prev_fqdn_no_www !=None: 
       if len(jsonLst)>0:
           res=processUpdates(jsonLst,fullJson)
           if res:
               print ('%s' % (res))
           jsonLst=[]
           fullJson={}
   if line[2].strip()!='None':
      fullJson=json.loads(line[2])
   else:
      jsonLst.append(json.loads(line[1]))
   prev_fqdn_no_www=fqdn_no_www


if fqdn_no_www == prev_fqdn_no_www :
    if len(jsonLst)>0:
        res=processUpdates(jsonLst,fullJson)
        if res:
            print( '%s' % (res))

