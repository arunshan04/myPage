#!/usr/bin/python2
import sys
import json

prev_fqdn_no_www=None
masterJson=""
newMasterJson=""
fqdn_no_www=None


for line in sys.stdin:
   line = line.split('\t')
   fqdn_no_www=line[0]
   if ( fqdn_no_www != prev_fqdn_no_www ) and prev_fqdn_no_www !=None: 
       if len(newMasterJson)!=len(masterJson) and len(newMasterJson)>0:
           print('\t%s' %(newMasterJson))
       else:
           print('\t%s' %(masterJson))
       newMasterJson=""
       masterJson=""
   if line[2].strip()!='None':
       masterJson=line[2].strip()
   else:
       newMasterJson=line[1].strip()
   prev_fqdn_no_www=fqdn_no_www


if fqdn_no_www == prev_fqdn_no_www :
    #print( '\t%s' % (processUpdates(newMasterJson,masterJson)))
    #if diff(newMasterJson,masterJson):
    #    print(newMasterJson)
    if len(newMasterJson)!=len(masterJson) and len(newMasterJson)>0:
        print('\t%s' %(newMasterJson))
    else:
        print('\t%s' %(masterJson))


