#!/bin/bash
#=======Process Daily Recoreds=============
export scriptsPath=/user/hadoop
export homePrefix=/user/hadoop
export streamingJar=/usr/lib/hadoop-mapreduce/hadoop-streaming-3.2.1-amzn-5.jar
export masterRecords=$homePrefix/master_records           # which contains upto date full records
export dailyInput=$homePrefix/daily_input                 # which contains daily recorords
export dailyOutput=$homePrefix/daily_output               # which contains daily outputs After compared with MasterRecords only Delta will be kept here
export masterRecordsTemp=$homePrefix/masterRecordsTemp    # temp output of Delta + Previous Master Records 
export LogsPath=$scriptsPath/logs

[ -d $LogsPath ] || mkdir -p $LogsPath
#sh -c "hdfs dfs -d $masterRecords" || hdfs dfs -mkdir -p $masterRecords


date=$(date '+%Y-%m-%d_%H:%M:%S')
inputRecords=$(hdfs dfs -cat $dailyInput/* 2>/dev/null| wc -l)
masterRecordsCnt=$(hdfs dfs -cat $masterRecords/*  2>/dev/null| wc -l)

echo "***********Input Records : "$inputRecords
echo "***********Input master Records  : "$masterRecordsCnt


if [[ $inputRecords -gt 0 ]];then
hdfs dfs -rmr $dailyOutput 2>/dev/null
hadoop jar $streamingJar \
-mapper $scriptsPath/mapper1.py \
-reducer $scriptsPath/reducer1.py \
-file $scriptsPath/mapper1.py \
-file $scriptsPath/reducer1.py \
-input  $dailyInput \
-input $masterRecords \
-output $dailyOutput \
-jobconf stream.num.map.output.key.fields=1 \
-jobconf mapred.text.key.comparator.options=-k1  2>&1 > $LogsPath/procesInputs_${date}.log


### This is the Incremental output contains the required data format
outputRecords=$(hdfs dfs -cat $dailyOutput/* | wc -l)
echo "**********output Records   : "$outputRecords

if [[ $outputRecords -gt 0 ]]; then
hdfs dfs -rmr $masterRecordsTemp
hadoop jar $streamingJar \
-mapper $scriptsPath/mapper2.py \
-reducer $scriptsPath/reducer2.py \
-file $scriptsPath/mapper2.py \
-file $scriptsPath/reducer2.py \
-input $masterRecords \
-input $dailyOutput \
-numReduceTasks	6 -output $masterRecordsTemp \
-jobconf stream.num.map.output.key.fields=1 \
-jobconf mapred.text.key.comparator.options=-k1  2>&1 > $LogsPath/procesInputs_${date}.log

newMaster=$(hdfs dfs -cat $masterRecordsTemp/* | wc -l)
echo "***********New Master Records    : "$newMaster

if [[ $newMaster -gt 0 ]]; then
## *********** Replace the Existing Master Recoreds *************
hdfs dfs -rmr $masterRecords
hdfs dfs -mv $masterRecordsTemp $masterRecords
fi


else
    echo "No Changes in the Existing Data"
fi

else
echo "No Input Found"
fi;
